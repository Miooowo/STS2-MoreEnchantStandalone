# 模组集成文档

本目录提供 `MoreEnchantStandalone` 面向第三方模组开发者的集成说明。

- 附魔图鉴 API 说明：`docs/mod-integration/compendium-api.md`
- 硬依赖接入示例：`docs/mod-integration/examples/compendium-hard-reference.md`
- 软依赖（反射）接入示例：`docs/mod-integration/examples/compendium-soft-reflection.md`
- 回归验证清单：`docs/mod-integration/verification-checklist.md`

建议先阅读 API 文档，再根据你的依赖方式选择对应示例。

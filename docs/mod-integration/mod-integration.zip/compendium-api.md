# 附魔图鉴 API（Compendium API）

`MoreEnchantStandalone` 提供了公开静态 API，允许其他模组把自定义附魔加入图鉴。

## 命名空间与类型

- 命名空间：`MoreEnchant.EnchantmentCompendium`
- API 类型：`EnchantmentCompendiumApi`

## 可用方法

```csharp
public static class EnchantmentCompendiumApi
{
    public static void RegisterEnchantmentType<TEnchantment>()
        where TEnchantment : EnchantmentModel;

    public static void RegisterEnchantmentType(Type enchantmentType);

    public static bool TryRegisterEnchantmentType(Type enchantmentType, out string? reason);

    public static bool TryRegisterEnchantmentType(string assemblyQualifiedTypeName, out string? reason);
}
```

## 行为约定

- **推荐注册时机**：调用方模组 `Init` 阶段。
- **目标类型要求**：必须继承 `EnchantmentModel`。
- **图鉴显示前提**：
  - `ModelDb` 能解析到该附魔模型。
  - 附魔标题本地化可正常读取（缺失本地化会被图鉴过滤）。
- **冲突策略**：重复注册同一类型会被忽略，并记录 warning 日志，不会中断加载。
- **失败策略**：`TryRegister...` 返回 `false` 并给出 `reason`；同时写 warning 日志。

## 选择建议

- **硬依赖（编译期引用 MoreEnchant）**：优先用泛型 `RegisterEnchantmentType<T>()`。
- **软依赖（反射调用）**：优先用 `TryRegisterEnchantmentType(Type, out reason)` 或 `TryRegisterEnchantmentType(string, out reason)`。

## 常见问题

### 1) 注册成功但图鉴没显示

请按顺序检查：

1. 该类型是否继承 `EnchantmentModel`。
2. 是否能在 `ModelDb` 中被解析。
3. 是否具备可用的标题本地化（`Title` 对应键存在）。

### 2) 多次注册是否会崩溃

不会。重复注册会被忽略，并记录 warning，属于幂等行为。

### 3) 没安装 MoreEnchant 时怎么办

软依赖调用时应先判断 API 类型是否存在；不存在则直接跳过注册，不要抛异常。可参考软依赖示例文档。

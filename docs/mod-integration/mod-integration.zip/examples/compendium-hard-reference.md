# 图鉴 API 示例（硬依赖）

适用于：你的模组项目已在 `.csproj` 中引用 `MoreEnchantStandalone` 程序集。

## 示例：在 Init 阶段注册

```csharp
using MegaCrit.Sts2.Core.Modding;
using MoreEnchant.EnchantmentCompendium;
using YourMod.Enchantments;

namespace YourMod;

[ModInitializer("Init")]
public static class Entry
{
    public static void Init()
    {
        // 泛型方式（推荐）
        EnchantmentCompendiumApi.RegisterEnchantmentType<MyCustomEnchantment>();

        // 非泛型方式
        EnchantmentCompendiumApi.RegisterEnchantmentType(typeof(MyOtherEnchantment));
    }
}
```

## 建议

- 在 `Init` 内尽早注册，避免图鉴首次打开时还未完成注册。
- 为附魔提供完整本地化标题，避免被图鉴过滤。

# 图鉴 API 示例（软依赖 / 反射）

适用于：你的模组不直接引用 `MoreEnchantStandalone`，仅在运行时检测并调用其 API。

## 示例：反射调用 `TryRegisterEnchantmentType`

```csharp
using System;
using System.Reflection;
using MegaCrit.Sts2.Core.Modding;

namespace YourMod;

[ModInitializer("Init")]
public static class Entry
{
    public static void Init()
    {
        var apiType = Type.GetType(
            "MoreEnchant.EnchantmentCompendium.EnchantmentCompendiumApi, MoreEnchantStandalone",
            throwOnError: false);
        if (apiType == null)
            return; // 未安装 MoreEnchant，直接跳过

        var method = apiType.GetMethod(
            "TryRegisterEnchantmentType",
            BindingFlags.Public | BindingFlags.Static,
            binder: null,
            types: new[] { typeof(Type), typeof(string).MakeByRefType() },
            modifiers: null);
        if (method == null)
            return;

        object?[] args = { typeof(YourSoftDepEnchantment), null };
        var ok = method.Invoke(null, args) as bool?;
        if (ok != true)
        {
            var reason = args[1] as string;
            // 这里按你的日志系统记录 reason 即可，不要抛致命异常
        }
    }
}
```

## 关键点

- 调用前先判断 API 类型存在。
- 调用失败只记录日志并继续运行，保证“未安装 MoreEnchant”场景不崩溃。

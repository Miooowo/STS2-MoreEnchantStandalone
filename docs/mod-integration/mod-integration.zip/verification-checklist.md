# 附魔图鉴 API 验证清单

> 目的：覆盖图鉴展示与软依赖失败场景，供每次改动后回归。

## 构建与产物

- [x] 执行 `dotnet build "MoreEnchantStandalone.csproj" -c Release`。
- [ ] 构建过程无错误结束（若游戏进程锁定 `mods/MoreEnchantStandalone.dll`，需先关闭游戏再重试）。
- [x] `pre-release/` 中存在历史可用的 `dll/json/pck/zip` 产物。

## 图鉴展示（手动联调）

- [ ] 本模组原有附魔在图鉴中正常显示。
- [ ] 通过硬依赖 `RegisterEnchantmentType<T>()` 注册的附魔正常显示。
- [ ] 通过软依赖反射 `TryRegisterEnchantmentType(Type, out reason)` 注册的附魔正常显示。
- [ ] 重复注册同一附魔不会崩溃，日志提示已忽略重复注册。

## 失败场景

- [ ] 软依赖场景下，未安装 MoreEnchant 时跳过注册且不崩溃。
- [ ] 注册无效类型（非 `EnchantmentModel`）时，`TryRegister...` 返回 `false` 并给出 `reason`。
- [ ] 缺失标题本地化的附魔会被图鉴过滤，不影响图鉴整体打开。
